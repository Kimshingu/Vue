<template lang="html">
  <h1>Header</h1>
</template>

<script>
export default {
}
</script>

<style lang="css" scoped>
h1 {
  color: #2F3B52;
  font-weight: 900;
  margin: 2.5rem 0 1.5rem;
}
</style>
