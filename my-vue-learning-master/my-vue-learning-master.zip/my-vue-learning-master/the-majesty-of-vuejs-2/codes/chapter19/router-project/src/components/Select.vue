<template>
    <lari-select></lari-select>
</template>

<script>
    import { LariSelect } from 'lari-select'
    export default {
        components: {
            LariSelect
        }
    }
</script>
